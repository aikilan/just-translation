import './assets/service-worker.ts--RqbWYqy.js';
