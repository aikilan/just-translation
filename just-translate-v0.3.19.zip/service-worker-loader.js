import './assets/service-worker.ts-BQcWckzl.js';
