import './assets/service-worker.ts-C3twNZZG.js';
