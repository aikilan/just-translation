function e(e){return chrome.runtime.sendMessage(e)}function t(e,t){return chrome.tabs.sendMessage(e,t)}export{t as n,e as t};
//# sourceMappingURL=chrome-api--rgIeROb.js.map