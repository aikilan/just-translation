function e(e){return e instanceof Error?e.message:`发生未知错误`}export{e as t};
//# sourceMappingURL=messages-CQotUX8N.js.map